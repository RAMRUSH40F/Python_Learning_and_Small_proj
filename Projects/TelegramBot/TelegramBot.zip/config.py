token = '5232909795:AAGd7ddL0QP88PgoGUIvcCal6WnZTGWk6OU'
sayhi = 'Рад видеть и служить вам. Напишите либо старт либо начать либо привет, чтобы увидеть,что я могу'
weather_api_id = 'fc387c704644cdbdec3279dc0bb0ce76'
family_chat_id = -1001601086563
admin_chat_id = 397596258
poll_min_number = 4
